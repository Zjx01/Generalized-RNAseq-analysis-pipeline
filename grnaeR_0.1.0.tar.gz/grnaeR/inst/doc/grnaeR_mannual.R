## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(grnaeR)

## ----installation and load the exampleData------------------------------------
# if (!require("BiocManager", quietly = TRUE))
#     install.packages("BiocManager")
#     BiocManager::install("DOSE")

## ----installation of grnaeR---------------------------------------------------
# Notice: the package should reside under current working directory for installation
# install.packages('grnaeR_0.1.0.tar.gz',repos = NULL) 

## -----------------------------------------------------------------------------
system.file(package = "grnaeR")|>list.files()

## ----load the example data----------------------------------------------------
library(DOSE)
data(geneList)
# have a view of the data
head(geneList)

## -----------------------------------------------------------------------------
library('enrichplot')
library('ggpubr')
library('org.Hs.eg.db')
library('DESeq2')
library('RColorBrewer')
library("pheatmap")

## ----filter_genelist----------------------------------------------------------
edo <- grnaeR::filter_genelist(geneList,standard_fc = 2)

## ----barplot------------------------------------------------------------------
barplot <- show_barplot(edo,showCategory_num = 20)
barplot

## ----dotplot------------------------------------------------------------------
dotplot<-show_dotplot(edo,showCategory_num=30)
dotplot

## -----------------------------------------------------------------------------
gene_network <- develop_Gene_Network(edo,geneList)

## ----loaddata-----------------------------------------------------------------
# working directory
dir = getwd()
file = paste(system.file('extdata', package = "grnaeR"),system.file('extdata', package = "grnaeR")|>list.files(),sep = '/')
# file: The path of rnaseq raw count
readcount = load_data(dir,file)

## ----totalcov_check-----------------------------------------------------------
total.cov =  check_totalcov_quality(readcount)

## ----genecov_check------------------------------------------------------------
gene.cov = check_genecovered_quality(readcount)

## ----checkRPKM----------------------------------------------------------------
calculate_RPKM(readcount)

## -----------------------------------------------------------------------------
type_vector = c(colnames(readcount))
condition_vector = c(c(rep('CRS',4)),c(rep('noCRS',5)))

## -----------------------------------------------------------------------------
dds = grnaeR::load_data_for_DESeq2(file,condition_vector,type_vector)
normalized_dds = normalize_dataset(dds)
check_sample_distance(normalized_dds)

## -----------------------------------------------------------------------------
select_DEGs = select_DEG(dds = dds,filter_thresh = 0,log2_fc = log(1.5,2), padjust = 0.05)
select_DEGs

