# Calcium Neuron Imaging 
to develop a tool to recognize Calcium imaging in neurons using neuron calcium imaging data from the "CodeNeuron" challenge and try to determine the spatial distribution of active cells
