from setuptools import setup

setup(name = 'calcium_neuron_imaging',
	version = '0.1.0',
	packages = ['cni_pkg']
)

